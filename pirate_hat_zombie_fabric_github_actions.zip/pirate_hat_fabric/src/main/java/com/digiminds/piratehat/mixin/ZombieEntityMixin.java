package com.digiminds.piratehat.mixin;

import com.digiminds.piratehat.PirateHatMod;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.LocalDifficulty;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ZombieEntity.class)
public abstract class ZombieEntityMixin {
    @Inject(method = "initEquipment", at = @At("TAIL"))
    private void piratehat$equipPirateHat(Random random, LocalDifficulty difficulty, CallbackInfo ci) {
        ZombieEntity zombie = (ZombieEntity) (Object) this;
        zombie.equipStack(EquipmentSlot.HEAD, PirateHatMod.PIRATE_HAT.getDefaultStack());
        // A small chance for the hat to drop when this zombie is killed.
        zombie.setEquipmentDropChance(EquipmentSlot.HEAD, 0.10F);
    }
}
