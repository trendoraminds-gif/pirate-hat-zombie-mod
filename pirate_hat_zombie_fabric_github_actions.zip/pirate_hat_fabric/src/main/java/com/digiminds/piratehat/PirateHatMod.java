package com.digiminds.piratehat;

import net.fabricmc.api.ModInitializer;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.Item;
import net.minecraft.item.equipment.ArmorMaterial;
import net.minecraft.item.equipment.EquipmentType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import net.minecraft.recipe.Ingredient;

import java.util.List;
import java.util.Map;

public class PirateHatMod implements ModInitializer {
    public static final String MOD_ID = "piratehat";
    public static final Identifier PIRATE_HAT_ID = Identifier.of(MOD_ID, "pirate_hat");

    public static final ArmorMaterial PIRATE_HAT_MATERIAL = new ArmorMaterial(
            Map.of(EquipmentType.HELMET, 1),
            10,
            SoundEvents.ITEM_ARMOR_EQUIP_LEATHER,
            () -> Ingredient.EMPTY,
            List.of(new ArmorMaterial.Layer(Identifier.of(MOD_ID, "pirate_hat"))),
            0.0F,
            0.0F
    );

    public static final Item PIRATE_HAT = Registry.register(
            Registries.ITEM,
            PIRATE_HAT_ID,
            new ArmorItem(PIRATE_HAT_MATERIAL, EquipmentType.HELMET, new Item.Settings().registryKey(RegistryKey.of(RegistryKeys.ITEM, PIRATE_HAT_ID)))
    );

    @Override
    public void onInitialize() {
        // The item is registered in the static initializer. The mixin equips it on zombies.
    }
}
